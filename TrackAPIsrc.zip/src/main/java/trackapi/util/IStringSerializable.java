package trackapi.util;

public interface IStringSerializable
{
    String getName();
}